# 🍗 Crispy Chicken UAE

Official **Crispy Chicken UAE** website landing page with offers, delivery information, and customer feedback.

## 🌟 Features
- Daily special offers & discounts
- Easy ordering via call or WhatsApp
- Delivery service across UAE
- Contact form for complaints & suggestions

## 📞 Contact
- Call Center: **600 527488**
- Mobile: **050 188 2206**
- Email: kenawe@crispychicken.rest  
- Website: [crispychicken-uae.com](https://crispychicken-uae.com)

## 🚀 Live Website
[Visit Crispy Chicken UAE on GitHub Pages](https://crispychicken0)
